"""Explicit extension of the same R1 owner for observed numerical task contexts."""

import copy
import hashlib
from pathlib import Path

import torch

from experiments.continuing_control.core import InteractiveR1
from sera.session_state import model_identity


def source_identity():
    folder = Path(__file__).parent
    return hashlib.sha256(b"".join((folder/name).read_bytes() for name in ("owner.py", "streams.py"))).hexdigest()


class LiveR1(InteractiveR1):
    def export_config(self):
        return {**super().export_config(), "live_schema": 1, "live_source": self.live_source,
                "live_contexts": sorted(self.live_contexts)}

    @classmethod
    def attach(cls, owner, contexts=None):
        if type(owner) is not InteractiveR1:
            raise ValueError("Expected the unchanged continuing predecessor")
        owner.__class__ = cls
        owner.live_source = source_identity()
        owner.live_contexts = {}
        for name, values in (contexts or {}).items():
            owner.set_context(name, values)
        return owner

    def set_context(self, name, values):
        if len(name) != 16 or any(c not in "0123456789abcdef" for c in name):
            raise ValueError("Invalid task context identity")
        value = torch.tensor(values, dtype=torch.float64)
        if value.shape != (5,) or not bool(torch.isfinite(value).all()):
            raise ValueError("Expected three learned coefficients, count and last observation")
        key = "live_stream_"+name
        if name in self.live_contexts:
            getattr(self, key).copy_(value)
        else:
            self.register_buffer(key, value)
            self.live_contexts[name] = key

    def contexts(self):
        return {name: getattr(self, key).tolist() for name, key in self.live_contexts.items()}


def base_snapshot(session):
    """Preserve the frozen A08 restore contract as one explicit part of the new owner."""
    result = session.snapshot()
    base = copy.deepcopy(session.owner)
    for key in base.live_contexts.values():
        delattr(base, key)
    base.__class__ = InteractiveR1
    result["owner_sha256"] = model_identity(base)
    return result
