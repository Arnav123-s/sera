"""Explicitly admitted, parameter-preserving interpreter migrations.

The original acquisition source remains the weight artifact's provenance.
The release retains every prior source byte and checks identical learned tensors
and derived inquiry results before saving a new implementation revision.
"""

TRAINING_SOURCES = {"1708da71bb6a7a5fe442691a0bd4f9f92e65c562e06afe37eb49b859dd682bc4"}
RUNTIME_SOURCES = {"1d44b9114bb829d5e3b47333dfc213c1213beba05503042e4128649ffeaf1961"}
GRAPH_SOURCES = {"6b32a70d0768f0cc81971f88f0ff22c2d068155bb1c861baf8df73824ce64248"}
