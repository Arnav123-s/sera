"""Replay saved solutions and independently check LP optimality conditions."""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
from scipy.optimize import linprog

def main(root: Path):
    records=json.loads((root/'records.json').read_text())
    summary=json.loads((root/'summary.json').read_text())
    protocol=json.loads((root/'protocol.json').read_text())
    runtime=json.loads((root/'runtime.json').read_text())
    assert runtime['source_sha256']==hashlib.sha256(Path(__file__).with_name('probe.py').read_bytes()).hexdigest()
    if (root/'arrays.npz').exists():
        raw=np.load(root/'arrays.npz', allow_pickle=False)
    else:
        packed=np.load(root/'arrays_dedup.npz', allow_pickle=False)
        index=json.loads((root/'array_index.json').read_text())
        class PackedArrays:
            def __getitem__(self,key):
                return packed[index[key]]
        raw=PackedArrays()
    max_delta=max_gap=max_dual_violation=0.
    counts={}; records_seen=set()
    for record in records:
        group, seed, solver=record['group'],record['seed'],record['solver']
        key=(group,seed,solver)
        assert key not in records_seen; records_seen.add(key)
        prefix=f'{group}_{seed}'
        a,y,x=raw[prefix+'_A'],raw[prefix+'_y'],raw[prefix+'_truth']
        saved=raw[prefix+'_'+solver]
        np.testing.assert_allclose(a@x,y,rtol=1e-12,atol=1e-12)
        if solver=='basis_pursuit':
            p=a.shape[1]
            solved=linprog(np.ones(2*p),A_eq=np.c_[a,-a],b_eq=y,bounds=(0,None),method='highs',
                 options={'dual_feasibility_tolerance':1e-9,'primal_feasibility_tolerance':1e-9})
            assert solved.success
            new=solved.x[:p]-solved.x[p:]
            # Mathematical certificate for l1 optimality, NOT for physical correctness.
            dual=solved.eqlin.marginals
            violation=float(max(0,np.max(np.abs(a.T@dual))-1))
            gap=float(abs(np.sum(np.abs(saved))-y@dual))
            assert violation<1e-7 and gap<1e-7
            max_gap=max(max_gap,gap); max_dual_violation=max(max_dual_violation,violation)
        else:
            new=np.linalg.lstsq(a,y,rcond=None)[0]
        delta=float(np.max(np.abs(new-saved)))
        max_delta=max(max_delta,delta)
        np.testing.assert_allclose(new,saved,rtol=1e-10,atol=1e-10)
        error=float(np.linalg.norm(saved-x)/np.linalg.norm(x))
        assert abs(error-record['relative_coefficient_error'])<1e-10
        success=error<protocol['exact_recovery_relative_l2_tolerance']
        assert success==record['exact_recovery']
        counts[(group,solver)]=counts.get((group,solver),0)+int(success)
        if group.startswith('fourier'):
            other='fourier_regular_aliasing' if group=='fourier_random' else 'fourier_random'
            np.testing.assert_array_equal(x,raw[f'{other}_{seed}_truth'])
            # Independent implementation checks the Fourier measurement matrix.
            q=raw[prefix+'_assessment_matrix']
            t=(np.arange(256)+.314159)/256
            independently=np.column_stack([np.ones(256)]+[
                f(2*np.pi*k*t)*np.sqrt(2) for k in range(1,33) for f in (np.cos,np.sin)])
            np.testing.assert_allclose(q,independently,rtol=1e-12,atol=1e-12)
            error_q=np.linalg.norm(q@(saved-x))/np.linalg.norm(q@x)
            assert abs(error_q-record['relative_heldout_signal_error'])<1e-10
    assert len(records_seen)==400
    for row in summary['results']:
        assert counts[(row['group'],row['solver'])]==row['exact_recoveries']
    # Alias checked without the probe's Fourier implementation.
    grid=np.arange(24)/24
    np.testing.assert_allclose(np.cos(2*np.pi*grid),np.cos(2*np.pi*25*grid),atol=3e-14)
    assert abs(np.cos(2*np.pi/48)-np.cos(2*np.pi*25/48))>1.9
    result={'replayed_solutions':len(records_seen),'checked_basis_pursuit_dual_certificates':200,
            'max_solution_absolute_difference':max_delta,'max_primal_dual_objective_gap':max_gap,
            'max_dual_constraint_violation':max_dual_violation,
            'scope':'Certificates establish optimization validity in the supplied model, not mechanism truth or SERA integration.'}
    print(json.dumps(result,indent=2))
    (root/'verification.json').write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--results',type=Path,required=True)
    main(p.parse_args().results)
