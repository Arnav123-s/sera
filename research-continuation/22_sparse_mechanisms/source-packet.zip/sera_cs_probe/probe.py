"""Reproducible compressed-sensing mechanism probe (not a SERA integration).

Uses a supplied identity or real-Fourier dictionary. No network is trained.
Basis pursuit receives only A and y, never the true support or held-out labels.
Dependencies: NumPy and SciPy. Run: python probe.py --output results
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import platform
import time
from pathlib import Path

import numpy as np
import scipy
from scipy.optimize import linprog

PROTOCOL = {
    'id': 'SERA-CS-DIAGNOSTIC-001', 'root_seed': 20260915, 'seeds': 50,
    'gaussian': {'ambient_dimension': 128, 'measurements': 32, 'sparse_nonzeros': 4},
    'fourier': {'max_frequency': 32, 'dictionary_size': 65, 'measurements': 24, 'nonzeros': 5},
    'noise': 0, 'solvers': ['basis_pursuit', 'minimum_norm'],
    'exact_recovery_relative_l2_tolerance': 1e-6,
    'basis_pursuit': 'min ||x||_1 subject to A x = y; positive/negative variable LP with scipy.optimize.linprog(method=highs)',
    'minimum_norm': 'numpy.linalg.lstsq(A, y, rcond=None)',
    'selection': 'No hyperparameter or checkpoint selection; all declared seeds reported.',
    'scope': 'Independent noiseless mechanism diagnostic; no upstream SERA tests or training, no learned dictionary, no online learning.',
    'cost_boundary': 'Both solvers receive the same measurements. Solver runtime is recorded, not compute-matched. Observation designs are supplied, not learned.',
    'measurement_counts': 'Each Fourier measurement is a scalar observation; not the two-coordinate SERA event count.',
    'success_definition': 'Recovers the entire coefficient vector, not merely a good fit to measured values.',
}

def save_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n', encoding='utf-8')

def relative_error(pred: np.ndarray, truth: np.ndarray) -> float:
    return float(np.linalg.norm(pred-truth)/max(float(np.linalg.norm(truth)), 1e-15))

def fourier(t: np.ndarray, max_frequency: int = 32) -> np.ndarray:
    t = np.asarray(t, dtype=np.float64)
    if t.ndim != 1 or not np.isfinite(t).all():
        raise ValueError('Finite one-dimensional coordinates required')
    phase = 2*np.pi*t[:, None]*np.arange(1, max_frequency+1)[None, :]
    # Orthonormal on [0,1]: constant, cos(1),sin(1),cos(2),sin(2),...
    pairs = np.stack([np.sqrt(2)*np.cos(phase), np.sqrt(2)*np.sin(phase)], axis=2)
    return np.column_stack([np.ones(len(t)), pairs.reshape(len(t), -1)])

def basis_pursuit(a: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, dict]:
    a, y = np.asarray(a, float), np.asarray(y, float)
    if a.ndim != 2 or y.shape != (a.shape[0],) or not np.isfinite(a).all() or not np.isfinite(y).all():
        raise ValueError('Incompatible or nonfinite system')
    p = a.shape[1]
    result = linprog(np.ones(2*p), A_eq=np.concatenate([a, -a], axis=1), b_eq=y,
                     bounds=(0., None), method='highs',
                     options={'dual_feasibility_tolerance': 1e-9, 'primal_feasibility_tolerance': 1e-9})
    if not result.success:
        raise RuntimeError(f'LP failed: {result.status}: {result.message}')
    return result.x[:p]-result.x[p:], {'iterations': int(result.nit), 'status': int(result.status)}

def coherence(a: np.ndarray) -> float:
    norms = np.linalg.norm(a, axis=0)
    # Zero columns represent another identifiability defect; do not divide by them.
    b = a[:, norms > 1e-12]/norms[norms > 1e-12]
    g = b.T @ b
    np.fill_diagonal(g, 0.)
    return float(np.max(np.abs(g))) if g.size else 0.

def sparse_vector(rng, p, k):
    x = np.zeros(p)
    ids = rng.choice(p, k, replace=False)
    x[ids] = rng.choice([-1., 1.], k)*rng.uniform(.5, 1.5, k)
    return x/np.linalg.norm(x)

def solve_case(group, seed, a, truth, arrays, records, eval_matrix=None):
    y = a @ truth
    prefix = f'{group}_{seed}'
    arrays[prefix+'_A'], arrays[prefix+'_truth'], arrays[prefix+'_y'] = a, truth, y
    if eval_matrix is not None:
        arrays[prefix+'_assessment_matrix'] = eval_matrix
    for solver in PROTOCOL['solvers']:
        start = time.perf_counter()
        if solver == 'basis_pursuit':
            estimate, diagnostics = basis_pursuit(a, y)
        else:
            estimate = np.linalg.lstsq(a, y, rcond=None)[0]
            diagnostics = {}
        elapsed = time.perf_counter()-start
        err = relative_error(estimate, truth)
        row = {'group': group, 'seed': seed, 'solver': solver, 'relative_coefficient_error': err,
               'exact_recovery': err < PROTOCOL['exact_recovery_relative_l2_tolerance'],
               'relative_measurement_residual': relative_error(a@estimate, y),
               'seconds': elapsed, 'column_coherence': coherence(a),
               'zero_columns': int((np.linalg.norm(a,axis=0)<1e-12).sum()), **diagnostics}
        if eval_matrix is not None:
            row['relative_heldout_signal_error'] = relative_error(eval_matrix@estimate, eval_matrix@truth)
        records.append(row)
        arrays[prefix+'_'+solver] = estimate

def analytic_alias():
    # Both one-sparse candidates are identical on the grid. A new feasible phase separates them.
    t = np.arange(24)/24
    x1 = np.zeros(65); x2 = np.zeros(65)
    x1[1+2*(1-1)] = 1.; x2[1+2*(25-1)] = 1.
    gap = float(np.max(np.abs(fourier(t)@(x1-x2))))
    query = np.array([1/48])
    return {'first_frequency': 1, 'second_frequency': 25, 'grid_samples': 24,
            'largest_observed_difference': gap,
            'extra_observation_t': float(query[0]),
            'first_extra_prediction': float((fourier(query)@x1)[0]),
            'second_extra_prediction': float((fourier(query)@x2)[0]),
            'extra_observation_difference': float(abs((fourier(query)@(x1-x2))[0])),
            'interpretation': 'A physically permitted off-grid observation can distinguish this pair. This does not certify all dictionary pairs or omitted mechanisms.'}

def summarize(records):
    rows = []
    for group in sorted({r['group'] for r in records}):
        for solver in PROTOCOL['solvers']:
            r = [x for x in records if x['group']==group and x['solver']==solver]
            n = len(r); k = sum(x['exact_recovery'] for x in r)
            phat = k/n; z=1.959963984540054
            denom=1+z*z/n; ctr=(phat+z*z/(2*n))/denom
            rad=z*math.sqrt(phat*(1-phat)/n+z*z/(4*n*n))/denom
            rows.append({'group':group, 'solver':solver, 'instances':n,
                'exact_recoveries':k, 'recovery_fraction':phat,
                'recovery_wilson95':[max(0.,ctr-rad),min(1.,ctr+rad)],
                'median_relative_coefficient_error':float(np.median([x['relative_coefficient_error'] for x in r])),
                'max_relative_measurement_residual':float(max(x['relative_measurement_residual'] for x in r)),
                'median_seconds':float(np.median([x['seconds'] for x in r]))})
    return rows

def run(out: Path):
    out.mkdir(parents=True, exist_ok=False)
    # Protocol is written before any experiment outcomes exist.
    save_json(out/'protocol.json', PROTOCOL)
    save_json(out/'runtime.json', {'python':platform.python_version(), 'numpy':np.__version__,
        'scipy':scipy.__version__, 'platform':platform.platform(),
        'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
    arrays, records = {}, []
    start = time.perf_counter()
    for seed in range(PROTOCOL['seeds']):
        rng=np.random.default_rng(np.random.SeedSequence([PROTOCOL['root_seed'],0,seed]))
        a=rng.normal(size=(32,128))/np.sqrt(32)
        sparse=sparse_vector(rng,128,4)
        dense=rng.normal(size=128); dense/=np.linalg.norm(dense)
        solve_case('gaussian_sparse',seed,a,sparse,arrays,records)
        solve_case('gaussian_dense',seed,a,dense,arrays,records)
        rng=np.random.default_rng(np.random.SeedSequence([PROTOCOL['root_seed'],1,seed]))
        truth=sparse_vector(rng,65,5)
        # The assessment grid is never passed to either solver.
        check=fourier((np.arange(256)+.314159)/256)
        tr=np.sort(rng.uniform(0,1,24))
        tg=np.arange(24)/24
        solve_case('fourier_random',seed,fourier(tr)/np.sqrt(24),truth,arrays,records,check)
        solve_case('fourier_regular_aliasing',seed,fourier(tg)/np.sqrt(24),truth,arrays,records,check)
    np.savez_compressed(out/'arrays.npz', **arrays)
    save_json(out/'records.json', records)
    save_json(out/'summary.json', {'results':summarize(records), 'alias_example':analytic_alias(),
        'wall_seconds':time.perf_counter()-start, 'solution_count':len(records),
        'distinct_truth_instances':150,'measurement_design_instances':200})
    print(json.dumps(json.loads((out/'summary.json').read_text()), indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args()
    run(args.output)
