# Local-agent experiment brief: sparse mechanism acquisition

This is a proposed follow-up to SERA-CS-DIAGNOSTIC-001. It is not an authorization to overwrite current work or run paid/unbounded compute.

## Reconcile first

Inspect the local Git HEAD, dirty files, research state and owned jobs. The public snapshot reviewed here is SERA `9104839400d5053152ca423be6da1efe355aa71a`. Local GG-GUARD-002 or later work can supersede this snapshot. Preserve old datasets, failed guards and source pins. The final families already used in GG-GUARD-001 and this diagnostic are development evidence, not untouched confirmatory families.

Read the attached README, protocol, source registry and raw results. Verify the standalone evidence once. Do not rebuild SERA around compressed sensing; add a bounded experimental challenger and keep its evidence labels explicit.

## Step 1: a fair recovery study

Proposed module names, not claimed existing files:
- `experiments/generative_memory/cs_recovery.py`
- `experiments/generative_memory/cs_study.py`
- `experiments/generative_memory/cs_verify.py`

Reuse the existing factual observation contracts and versioned bounded expression interpreter in `experiments/generative_memory/core.py` where compatible. Freeze a common dictionary for all methods. Include the current finite subset-selection route on dictionary sizes where exhaustive search is practical, a dense ridge/least-squares baseline, basis pursuit for noiseless observations, calibrated LASSO or constrained sparse regression for noise, and an established greedy sparse solver. Give every method equal support, selection/calibration access, observation budget and declared tuning budget. A hidden-support oracle is an explicitly privileged upper bound, never a peer learner.

Vary dictionary size, true sparsity, sample count, noise, precision and sampler. Include unseen mixtures of dictionary terms, off-grid frequencies, localized exceptions, dense random coefficients, corrupted observations and mechanisms absent from the dictionary. Separate recovery of coefficients from recovery of predictions and from correct causal identification.

Freeze the protocol before final labels are scored. Write per-instance errors, coefficients, support estimates, data IDs, solver status, runtime, peak-memory measurement method and total bytes. Define and report any inconclusive or failed solve.

## Step 2: observations that distinguish models

Reuse `acquisition.py` contracts only where the action meanings match. Permit no access to hidden full trajectories to manufacture cheap projections. Include scalar versus vector observation accounting, query movement/reset cost, and a random exploration control. Compare equal paid-observation counts and equal total-work budgets separately.

Maintain alternatives from multiple plausible dictionaries. Within-dictionary disagreement alone cannot discover a function that every candidate omits. Add independent predictive challenge queries or a registered escape rule. Numerical coherence/rank diagnostics must not be called universal recovery certificates.

Carry forward the failed applicability gate. Existing empirical Gaussian or guard probabilities are not automatically calibrated after sparse support selection or query-policy changes. Use prospective world-disjoint calibration and assessment appropriate to the selected policy. Report conditional accepted-answer risk and useful coverage, not pooled accuracy alone.

## Step 3: integration and actual use

After a component passes its prospective gates, register it through the declared shared owner and preserve parameter alias identities, evidence roles, dependencies and restore behavior. Test multiple questions against the same acquired situation. Conditional completion is not yet causal imagination: require a downstream planning/control task before claiming decision-improving rollouts.

Require factual outcomes to validate new generator capabilities. Teacher-derived distillation targets, if tested, must retain their non-observational provenance. Demonstrate a positive effect on an independently assessed downstream route; registering buffers in the owner is not that effect.

## Step 4: reusable dictionaries and investigator learning

Only after the inference path is understood, learn reusable dictionary elements across tasks. Keep old dictionary versions until retained codes can be migrated or regenerated from permissible evidence. Compare fixed and learned dictionaries at controlled total storage and acquisition costs. Test wrong old-support priors and loss of plasticity.

For the learning-procedure claim, hold starting knowledge fixed while swapping old/new acquisition policies. Also cross old/new knowledge with both policies. Charge dictionary training, investigator training, rejected work and validation. A smaller number of measurements on a familiar sparse family is not by itself recursive self-improvement.

## Decision gate

Promote only when the challenger improves an explicitly registered cost-to-capability measure at the required reliability, preserves protected capabilities, and replays from a clean process. If not, preserve it as a failed or conditional variant and select the next discriminating experiment. Do not tune repeatedly on final results, silently relax thresholds, or replace broad goals with this finite dictionary benchmark.
