# Compressed sensing for the current SERA architecture

Research date: 15 September 2026. This is a focused research addendum and a standalone, executed mechanism diagnostic. It is not a SERA patch, a neural-training study, or a replacement for the earlier research packs.

## Decision

Investigate compressed sensing as **sparse mechanism acquisition with deliberately informative measurements**, not as a universal memory compressor. The closest extensions to the user's generative-circle idea are compressed sensing with generative models, sparse system identification, online dictionary learning, and recovery with partially known support.

The intended destination remains a persistent learner that acquires compact executable explanations, predicts and conditionally imagines consequences, investigates failures, corrects itself, retains valid abilities and improves its acquisition procedure. The diagnostic below does not establish that destination.

## Current repository reconciliation

The GitHub main ref was read again. It resolves to `9104839400d5053152ca423be6da1efe355aa71a`, the same published snapshot used in the preceding v3 audit. No uncommitted local files or running jobs were inspected. No GitHub changes were made.

Read at that pin:

- `research-continuation/RESEARCH_STATE.json`
- `research-continuation/01_audit/final-architecture-comparison.md`
- `research-continuation/15_applicability/report.md`
- `experiments/generative_memory/core.py` (the supplied dictionary, design matrices, fitting and prediction code)

The state/audit records report completed restricted geometry and fixed-inquiry studies, an analytic generator workspace registered in the shared R1 owner, and an applicability candidate whose conditional-risk gate failed. The audit explicitly distinguishes common ownership from positive neural transfer: the analytic generator posterior is not coupled into the recurrent fusion computation. Investigator training and integrated successor-generation tests remain open in this published snapshot.

The core already performs bounded model/subset selection over supplied polynomial and trigonometric atoms. Therefore adding sparsity is not a completely new conceptual step. A useful challenger must offer better unknown-support recovery or scalability under the *same* dictionary and observation access, not merely receive a richer library than its controls.

The current applicability report gives local-exception accepted-answer risk 46.3%, piecewise-drift risk 65.8%, and an observational-alias example with 98.48% assigned validity. These are repository-reported outcomes, not retrained here. This is the primary reason to keep measurement identifiability and model adequacy separate from reconstruction optimization.

## Why the screenshot is relevant

AASF's own published account describes Tao's compressed-sensing discussion. The underlying foundational work is from the mid-2000s, not a newly invented 2026 method. The operative result is conditional recovery of structured signals from fewer measurements; it does not permit arbitrary independent information to be recovered from insufficient data.

For a known dictionary, write `y = A c + e`, with a coefficient vector c containing only s active entries among p possibilities. Suitable measurement designs permit sparse recovery with measurement counts on the order of `s log(p/s)`, with constants and failure probabilities depending on assumptions. The noiseless baseline is basis pursuit: minimize `||c||_1` subject to `A c = y`.

Under suitable restricted-isometry conditions, noisy recovery has an error bound of the form

`||c_hat - c||_2 <= C0 * sigma_s(c)_1 / sqrt(s) + C1 * epsilon`,

where sigma_s is the best s-term approximation error and epsilon bounds measurement noise. These are mathematical assumptions, not properties automatically satisfied by a learned world model.

Necessary and sufficient for uniqueness of every s-sparse solution is absence of a nonzero 2s-sparse vector in the kernel of A. This uniqueness condition alone is not the full guarantee for l1 minimization; stronger null-space/restricted-isometry conditions justify the solver.

For fixed nonlinear generators, replace the sparse set by the range of G: infer z from `y = M G(z) + e`. Distinct allowed outputs must remain distinguishable after measurement. The generator-recovery literature explicitly includes representation error and optimization error in its bounds. If the true process lies outside the generator's range, a confident latent fit can be wrong.

If c is already known and sparse, storing its nonzero values and positions can be cheaper than storing compressed measurements. If forming a measurement requires reading a whole hidden trajectory, that acquisition work must be counted. Do not generate random projections from evaluator-only trajectory values and call them a handful of cheap observations.

## Executed diagnostic

`SERA-CS-DIAGNOSTIC-001` was written before outcomes were generated. It has no learned representation, no hyperparameter search, no observation noise, and no checkpoint selection.

The Gaussian test uses 128 unknown coefficients, 32 linear measurements, and either four nonzeros or a dense signal. The trajectory analogue uses a fixed real Fourier dictionary with 65 coefficients (constant plus sine/cosine components at frequencies 1 through 32), five nonzeros and 24 scalar observations. The active coefficient locations are not given to the solver. Random-phase and equispaced-phase cases use the same underlying truths. All phase coordinates and dictionary functions are supplied.

Each condition has 50 instances. There are 150 distinct truth instances, 200 design-instance settings, and 400 reconstruction solves across basis pursuit and minimum-norm least squares. This is not 400 trained neural models. Solver compute is measured but not matched; both solvers receive identical observations.

Recovery means relative whole-coefficient L2 error below 1e-6, not merely small measured-data residual.

| Condition | Basis pursuit recovered | Minimum norm recovered |
|---|---:|---:|
| Four-sparse, Gaussian measurements | 50/50 | 0/50 |
| Dense, Gaussian measurements | 0/50 | 0/50 |
| Five-sparse Fourier, random phases | 49/50 | 0/50 |
| Same Fourier truths, equispaced aliasing phases | 1/50 | 0/50 |

The one random-phase failure is preserved. The recovery proportion's Wilson 95% interval is about 89.5% to 99.65%; this interval concerns the declared random-instance experiment, not arbitrary SERA tasks.

All 400 saved solutions replayed with zero observed absolute coefficient discrepancy. An independent verifier checked 200 LP dual-feasibility/primal-dual-gap certificates: maximum objective gap 4.77e-13 and maximum dual-constraint violation 2.38e-12. These certify optimization within the specified linear model, not that the inferred mechanism is true.

Even incorrect solutions match the observed measurements nearly perfectly. This directly illustrates why low training residual must not serve as an applicability certificate.

### Explicit alias and acquisition example

On `t_j = j/24`, `cos(2 pi t)` and `cos(2 pi 25 t)` agree. Both hypotheses are one-sparse in the dictionary. At `t = 1/48` they disagree. With the diagnostic's sqrt(2) normalization, the extra-observation predictions differ by about 2.80423. This is a supplied, mathematically selected observation, not a learned investigator. It distinguishes this pair, not all possible omitted mechanisms.

### Limits

No noise robustness, online adaptation, causal control benefit, dictionary acquisition, neural transfer, broad knowledge completion, or recursive learning improvement was established in this diagnostic. The minimum-norm control is useful for demonstrating the role of sparsity, but is not a substitute for strong sparse-recovery and current-SERA baselines.

## Proposed architecture extension

Retain the shared recurrent learner. Add an isolated sparse-generator challenger with the following contracts:

1. **Versioned feature/program dictionary.** Map admissible observations and actions to candidate terms. Record supplied versus learned terms, units, precision and all code dependencies. Normalize columns using an explicit frozen rule and preserve the corresponding coefficient units.
2. **Sparse recovery.** Infer a small set of active terms from factual measurements. Start with standard solvers; the theorem is not a reason to invent a new optimizer prematurely.
3. **Identifiability diagnostics.** Track zero columns, duplicated/near-duplicated columns, conditioning on candidate supports, and disagreement between compatible mechanisms. Sampled support checks are diagnostics, not a global proof over every sparse support.
4. **Adequacy testing.** Use new observed outcomes, negative families and query-policy-aware validation. A support-conditioned covariance ignores support-selection uncertainty; do not reuse it as a universally calibrated posterior.
5. **Investigation.** Select only permitted and costed observations. Compare random, equispaced, space-filling and disagreement-directed probes. Use separate queries to challenge the dictionary, not only to sharpen parameters inside it.
6. **Consolidation.** Store recovered executable terms, coefficients, guards, uncertainty, provenance and dependency versions. Preserve exceptions or unresolved alternatives instead of forcing them into a sparse model.
7. **Continual revision.** Test warm-start/partial-support recovery against scratch recovery, including deliberately wrong prior support. Dictionary changes require state/code migration and revalidation.

The linear-in-coefficients form can represent nonlinear dynamics through a nonlinear feature dictionary. For example, use a discrete transition equation `z_(t+1)-z_t = Phi(z_t,a_t) c + noise` to avoid granting exact simulator derivatives. Eventually move to measured partial state and reachable actions without free resets. Learning a supplied-feature sparse equation is not the same as discovering its coordinate system or causal semantics.

## Next experiment: proposed, not executed

Read `NEXT_EXPERIMENT.md`. The first SERA integration must preserve the current failed-guard status, compare equal dictionaries and feedback, keep previous final families out of novel claims, and measure cost to verified downstream capability. Do not promote the challenger solely because sparse synthetic signals reconstruct.

## Running the delivered evidence

Use an isolated Python environment with NumPy and SciPy. The measured environment was Python 3.13.5, NumPy 2.3.5 and SciPy 1.17.0. No automatic package installation is performed.

From this directory:

```text
python verify.py --results results
python probe.py --output fresh_results
python verify.py --results fresh_results
```

`probe.py` refuses to overwrite an existing output directory. The delivered archive stores arrays losslessly deduplicated in `results/arrays_dedup.npz` with `array_index.json`; the verifier reads either that format or the freshly generated `arrays.npz`. Deduplication is storage engineering, not an additional compressed-sensing result. Timings may change between runs; cross-version optimal solutions can also differ in nonunique cases. Do not silently relax scientific tolerances to obtain a replay pass.

See `SOURCES.json` for primary literature and pinned repository paths. A blocked container network prevented obtaining a full checkout for execution. The repository audit used the connected GitHub reader; the executed code here is independent.
