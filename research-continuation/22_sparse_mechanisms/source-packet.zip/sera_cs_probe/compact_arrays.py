"""Losslessly deduplicate repeated NumPy arrays; this is not compressed sensing."""
import hashlib
import json
from pathlib import Path
import numpy as np

def compact(root: Path):
    full = np.load(root/'arrays.npz',allow_pickle=False)
    unique, index = {}, {}
    for name in full.files:
        arr=np.ascontiguousarray(full[name])
        h=hashlib.sha256(str(arr.dtype).encode()+str(arr.shape).encode()+arr.tobytes()).hexdigest()
        slot='a_'+h
        unique.setdefault(slot,arr)
        index[name]=slot
    np.savez_compressed(root/'arrays_dedup.npz',**unique)
    (root/'array_index.json').write_text(json.dumps(index,sort_keys=True,indent=2)+'\n')
    compacted=np.load(root/'arrays_dedup.npz',allow_pickle=False)
    for name,slot in index.items():
        np.testing.assert_array_equal(full[name],compacted[slot])
    print(json.dumps({'logical_arrays':len(index),'unique_arrays':len(unique),
        'original_bytes':(root/'arrays.npz').stat().st_size,
        'compacted_bytes':(root/'arrays_dedup.npz').stat().st_size,
        'interpretation':'Byte-identical deduplication of repeated experiment arrays, not a scientific CS result.'},indent=2))

if __name__=='__main__':
    compact(Path(__file__).resolve().parent/'results')
