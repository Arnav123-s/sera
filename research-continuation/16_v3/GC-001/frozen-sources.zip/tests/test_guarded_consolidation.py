import copy

import pytest
import torch

from experiments.guarded_consolidation.core import (
    SCHEMA,
    Library,
    Work,
    compile_definition,
    teaching_trace,
)
from experiments.guarded_consolidation.study import TRAIN_INPUTS, base
from sera.shared import SharedR1
from sera.storage import digest
from sera.world_graph import ExecutableDefinition, ExecutableGraph, GraphStore, SharedOwnerRef


@pytest.fixture
def fixture():
    interpreter, work = digest("test-interpreter"), Work()
    relation = base("affine", interpreter)
    traces = [teaching_trace(relation.body["left"], inputs, work, str(i)) for i, inputs in enumerate(TRAIN_INPUTS)]
    definition = compile_definition(relation, traces, SCHEMA, interpreter, work)
    owner = SharedOwnerRef(SharedR1(width=8, heads=2, memory_dim=2))
    library = Library(GraphStore(ExecutableGraph(SCHEMA, interpreter, (relation, definition))), owner, work)
    return library, relation, definition, traces, interpreter


def test_acquired_program_parameterizes_values_and_handles_new_bindings(fixture):
    library, relation, definition, _, _ = fixture
    assert definition.body["program"] == ["mul", ["sub", ["input", "c"], ["input", "b"]], ["inv", ["input", "a"]]]
    assert definition.body["proof"]["accepted_inputs"] == 1210
    assert library.answer(relation.identity, dict(a=4, b=5, c=6), Work()) == 3
    assert "answers" not in definition.body


@pytest.mark.parametrize("inputs", [dict(a=0, b=5, c=6), dict(a=True, b=5, c=6), dict(a=4, b=-1, c=6), dict(a=4, b=5, c=11)])
def test_necessary_assumptions_are_preserved(fixture, inputs):
    library, relation, _, _, _ = fixture
    assert library.answer(relation.identity, inputs, Work()) is None


def test_omitting_inverse_guard_creates_an_incorrect_answer(fixture):
    library, relation, _, _, _ = fixture
    assert library.answer(relation.identity, dict(a=0, b=5, c=6), Work(), omit_guard=True) == 0


def test_predictions_and_forged_observations_cannot_teach(fixture):
    _, relation, _, traces, interpreter = fixture
    changed = copy.deepcopy(traces)
    changed[0]["evidence"] = "imagined"
    with pytest.raises(ValueError, match="Imagined"):
        compile_definition(relation, changed, SCHEMA, interpreter, Work())
    changed = copy.deepcopy(traces)
    changed[0]["observed_solutions"] = [9]
    with pytest.raises(ValueError, match="Forged"):
        compile_definition(relation, changed, SCHEMA, interpreter, Work())


def test_correction_removes_old_shortcut_and_repair_is_a_new_program(fixture):
    library, relation, definition, _, interpreter = fixture
    revised = base("affine", interpreter, corrected=True)
    update = library.store.replace((revised,), expected_parent=library.store.current.identity)
    assert update.invalidated == (definition.name,)
    assert library.answer(revised.identity, dict(a=4, b=5, c=6), Work()) is None
    traces = [teaching_trace(revised.body["left"], inputs, Work(), str(i)) for i, inputs in enumerate(TRAIN_INPUTS)]
    new = compile_definition(revised, traces, SCHEMA, interpreter, Work())
    library.store.replace((new,), expected_parent=library.store.current.identity)
    assert library.answer(revised.identity, dict(a=4, b=5, c=6), Work()) == 0


def test_restore_reproves_and_owner_change_invalidates(fixture):
    library, relation, definition, _, interpreter = fixture
    restored = Library.restore(library.record(), library.owner, Work())
    assert restored.record() == library.record()
    body = definition.body
    body["program"] = ["input", "c"]
    body["nonzero_conditions"] = []
    forged = ExecutableDefinition.build(definition.name, body, SCHEMA, interpreter, dependencies=definition.dependencies)
    graph = ExecutableGraph(SCHEMA, interpreter, (relation, forged))
    record = {"owner_sha256": library.owner_id, "graph": graph.record(), "graph_sha256": graph.identity}
    with pytest.raises(ValueError, match="proof"):
        Library.restore(record, library.owner, Work())
    with torch.no_grad():
        next(library.owner.owner.parameters()).add_(1)
    with pytest.raises(ValueError, match="Owner changed"):
        library.answer(relation.identity, dict(a=4, b=5, c=6), Work())
